# KING PRO

Aplicativo Android de sensibilidade, IA e ferramentas de configuração/desempenho.

## O que já está incluído
- Interface KING PRO em Jetpack Compose
- Gerador de sensibilidade com valores editáveis
- Tela da Mihh IA
- Clonar Sensibilidade (interface)
- Coach IA e seletor de vídeo
- Booster com Calibrar X/Y, Calibrar Toque e Performance
- Informações do aparelho
- Integração básica com Shizuku para detectar Binder e solicitar permissão
- Tela de planos FREE/PRO/ELITE
- Ícone baseado na imagem fornecida

## Importante
Este projeto não altera código, APK, executáveis ou arquivos internos do Free Fire.
As funções avançadas precisam ser implementadas somente com APIs/recursos que o Android e o dispositivo realmente disponibilizem.

## Build
Abra a pasta no Android Studio/IDE compatível com Gradle e execute:

./gradlew assembleDebug

O APK de debug será gerado em:
app/build/outputs/apk/debug/app-debug.apk

Dependências atuais do projeto seguem AndroidX/Compose e Shizuku API.

## Compilar pelo GitHub Actions (celular)
1. Crie um repositório no GitHub.
2. Envie o conteúdo desta pasta para o repositório (não coloque o ZIP dentro de outro ZIP).
3. Abra a aba Actions.
4. Selecione "Build KING PRO APK".
5. Toque em "Run workflow".
6. Quando terminar, abra a execução concluída e baixe o artefato "KING-PRO-debug".
7. Dentro dele estará o APK instalável.

O workflow usa Java 17, Android SDK 36 e Gradle 8.13 em um runner Linux do GitHub.
