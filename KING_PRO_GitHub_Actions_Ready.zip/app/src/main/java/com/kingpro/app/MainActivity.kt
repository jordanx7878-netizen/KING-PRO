package com.kingpro.app

import android.content.Intent
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val shizukuRequestCode = 7001

    private val videoPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            // The selected video is intentionally kept as a URI only.
            // A real backend can upload/process it later.
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KingProTheme {
                KingProApp(
                    onPickVideo = { videoPicker.launch("video/*") },
                    onRequestShizuku = { requestShizukuPermission() }
                )
            }
        }
    }

    private fun requestShizukuPermission() {
        try {
            if (Shizuku.isPreV11()) return
            if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != 0) {
                Shizuku.requestPermission(shizukuRequestCode)
            }
        } catch (_: Throwable) {
            // UI reports unavailable status.
        }
    }
}

@Composable
fun KingProTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Color(0xFFE50914),
        secondary = Color(0xFFFF4D4D),
        background = Color(0xFF080808),
        surface = Color(0xFF141414),
        surfaceVariant = Color(0xFF202020),
        onBackground = Color.White,
        onSurface = Color.White
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

enum class Page(val title: String) {
    HOME("KING PRO"),
    SENSI("Gerador de Sensi"),
    MIHH("Mihh IA"),
    CLONE("Clonar Sensibilidade"),
    COACH("Coach IA"),
    BOOSTER("Booster"),
    DEVICE("Meu Aparelho"),
    SHIZUKU("Shizuku"),
    PLANS("Meu Plano")
}

@Composable
fun KingProApp(onPickVideo: () -> Unit, onRequestShizuku: () -> Unit) {
    var page by remember { mutableStateOf(Page.HOME) }

    Scaffold(
        containerColor = Color(0xFF080808),
        bottomBar = {
            if (page != Page.HOME) {
                NavigationBar(containerColor = Color(0xFF101010)) {
                    NavigationBarItem(
                        selected = false,
                        onClick = { page = Page.HOME },
                        icon = { Icon(Icons.Default.Home, null) },
                        label = { Text("Início") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = { page = Page.SENSI },
                        icon = { Icon(Icons.Default.Tune, null) },
                        label = { Text("Sensi") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = { page = Page.BOOSTER },
                        icon = { Icon(Icons.Default.Bolt, null) },
                        label = { Text("Booster") }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (page) {
                Page.HOME -> HomePage { page = it }
                Page.SENSI -> SensiPage()
                Page.MIHH -> MihhPage()
                Page.CLONE -> ClonePage()
                Page.COACH -> CoachPage(onPickVideo)
                Page.BOOSTER -> BoosterPage()
                Page.DEVICE -> DevicePage()
                Page.SHIZUKU -> ShizukuPage(onRequestShizuku)
                Page.PLANS -> PlansPage()
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String = "") {
    Column(Modifier.fillMaxWidth().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.king_pro_logo),
                contentDescription = "KING PRO",
                modifier = Modifier.size(54.dp),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontSize = 24.sp, fontWeight = FontWeight.Black)
                if (subtitle.isNotBlank()) Text(subtitle, color = Color.LightGray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun HomePage(go: (Page) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Header("KING PRO", "Sensibilidade • IA • Performance") }
        item { StatusCard() }
        val cards = listOf(
            Triple("🎯", "Gerador de Sensi", Page.SENSI),
            Triple("🤖", "Mihh IA", Page.MIHH),
            Triple("👤", "Clonar Sensibilidade", Page.CLONE),
            Triple("🎥", "Coach IA", Page.COACH),
            Triple("⚡", "Booster", Page.BOOSTER),
            Triple("📱", "Meu Aparelho", Page.DEVICE),
            Triple("🔐", "Shizuku / ADB", Page.SHIZUKU),
            Triple("💳", "Meu Plano", Page.PLANS)
        )
        items(cards) { (icon, name, target) ->
            FeatureCard(icon, name) { go(target) }
        }
        item {
            Text(
                "As ferramentas do KING PRO funcionam dentro das capacidades autorizadas pelo Android e pelo dispositivo.",
                color = Color.Gray,
                fontSize = 12.sp,
                modifier = Modifier.padding(8.dp)
            )
        }
    }
}

@Composable
fun StatusCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF181818)),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("PLANO ATUAL", color = Color(0xFFFF4D4D), fontWeight = FontWeight.Bold)
            Text("FREE", fontSize = 20.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            Text("Análises Mihh: 2/dia")
            Text("Perfis: 1")
            Text("Coach IA: tokens")
        }
    }
}

@Composable
fun FeatureCard(icon: String, title: String, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(
            Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(icon, fontSize = 28.sp)
            Spacer(Modifier.width(16.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFE50914))
        }
    }
}

@Composable
fun PageTitle(title: String, subtitle: String) {
    Column(Modifier.padding(20.dp)) {
        Text(title, fontSize = 27.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = Color.Gray)
    }
}

@Composable
fun SensiPage() {
    val values = remember { mutableStateMapOf(
        "Geral" to 95, "Red Dot" to 90, "Mira 2x" to 85, "Mira 4x" to 78, "AWM" to 55, "Olhadinha" to 70
    ) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { PageTitle("🎯 Gerador de Sensi", "Configure e salve seu perfil") }
        item {
            Button(
                onClick = {
                    values["Geral"] = 95
                    values["Red Dot"] = 92
                    values["Mira 2x"] = 87
                    values["Mira 4x"] = 80
                    values["AWM"] = 58
                    values["Olhadinha"] = 72
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE50914))
            ) { Text("GERAR SENSI") }
        }
        values.forEach { (name, value) ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row {
                            Text(name, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Text(value.toString(), color = Color(0xFFFF4D4D), fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = value.toFloat(),
                            onValueChange = { values[name] = it.toInt() },
                            valueRange = 0f..100f
                        )
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                Text("COPIAR CONFIGURAÇÃO")
            }
        }
    }
}

@Composable
fun MihhPage() {
    var message by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Olá! Eu sou a Mihh. Me diga seu aparelho e seu estilo de jogo.") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        PageTitle("🤖 Mihh IA", "Assistente especializada em sensibilidade")
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Mihh", color = Color(0xFFFF4D4D), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text(answer)
                Spacer(Modifier.weight(1f))
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Ex.: Infinix, jogo rush...") }
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        answer = if (message.isBlank()) {
                            "Me conte seu aparelho e seu estilo de jogo para eu montar uma recomendação."
                        } else {
                            "Análise inicial: vou considerar \"$message\" e gerar uma sugestão. Ajuste os valores no Gerador de Sensi."
                        }
                        message = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ANALISAR") }
            }
        }
    }
}

@Composable
fun ClonePage() {
    var link by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        PageTitle("👤 Clonar Sensibilidade", "Cole um link de YouTube ou TikTok")
        OutlinedTextField(
            value = link,
            onValueChange = { link = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Link") }
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("CLONAR") }
        Spacer(Modifier.height(20.dp))
        Text(
            "O sistema deve usar somente informações publicamente disponíveis. Se os valores não estiverem presentes, não inventará uma configuração.",
            color = Color.Gray
        )
    }
}

@Composable
fun CoachPage(onPickVideo: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        PageTitle("🎥 Coach IA", "Análise de gameplay")
        Text("Formatos: MP4/MOV • até 20 minutos • até 1 GB", color = Color.Gray)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onPickVideo, modifier = Modifier.fillMaxWidth()) {
            Text("ENVIAR VÍDEO")
        }
        Spacer(Modifier.height(14.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("O Coach poderá analisar", fontWeight = FontWeight.Bold)
                Text("• movimentação\n• controle de mira\n• velocidade de arrasto\n• consistência\n• situações de dificuldade")
            }
        }
    }
}

@Composable
fun BoosterPage() {
    val tools = listOf(
        "Calibrar X", "Calibrar Y", "Calibrar Toque",
        "Performance / Desempenho", "Sensi de Tela",
        "Cursor Móvel", "Estabilidade de FPS", "Economia de bateria"
    )
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { PageTitle("⚡ Booster", "Ferramentas de configuração e otimização") }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF211010)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    "PRO: até 100% • ELITE: até 200%",
                    Modifier.padding(16.dp),
                    color = Color(0xFFFF4D4D),
                    fontWeight = FontWeight.Bold
                )
            }
        }
        items(tools) { tool ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tool, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Button(onClick = {}) { Text("ABRIR") }
                }
            }
        }
        item {
            Text(
                "Estas ferramentas não modificam o código, APK, executáveis ou arquivos internos do Free Fire.",
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun DevicePage() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val metrics = context.resources.displayMetrics
    val refresh = try {
        val wm = context.getSystemService(android.content.Context.WINDOW_SERVICE) as android.view.WindowManager
        wm.defaultDisplay.refreshRate
    } catch (_: Throwable) { 0f }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { PageTitle("📱 Meu Aparelho", "Informações disponíveis ao aplicativo") }
        item { InfoRow("Fabricante", Build.MANUFACTURER) }
        item { InfoRow("Modelo", Build.MODEL) }
        item { InfoRow("Android", Build.VERSION.RELEASE) }
        item { InfoRow("SDK", Build.VERSION.SDK_INT.toString()) }
        item { InfoRow("Resolução", "${metrics.widthPixels} × ${metrics.heightPixels}") }
        item { InfoRow("Densidade", metrics.densityDpi.toString()) }
        item { InfoRow("Taxa de atualização", if (refresh > 0) "%.0f Hz".format(refresh) else "Indisponível") }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151515))) {
        Row(Modifier.fillMaxWidth().padding(15.dp)) {
            Text(label, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(value, color = Color.LightGray)
        }
    }
}

@Composable
fun ShizukuPage(onRequest: () -> Unit) {
    val connected = remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        connected.value = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        PageTitle("🔐 Shizuku / ADB", "Acesso opcional e autorizado")
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp)) {
                Text(
                    if (connected.value) "● Shizuku conectado" else "○ Shizuku não conectado",
                    color = if (connected.value) Color(0xFF5BE37A) else Color(0xFFFF4D4D),
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(10.dp))
                Text("O KING PRO só usa operações que o Android/Shizuku realmente autorizar.")
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onRequest, modifier = Modifier.fillMaxWidth()) {
            Text("SOLICITAR PERMISSÃO")
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = {
            try { contextOpenShizuku() } catch (_: Throwable) {}
        }, modifier = Modifier.fillMaxWidth()) {
            Text("ABRIR CONFIGURAÇÃO DO SHIZUKU")
        }
    }
}

fun contextOpenShizuku() {
    // Placeholder intentionally avoids launching undocumented manager internals.
}

@Composable
fun PlansPage() {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { PageTitle("💳 Meu Plano", "Escolha os recursos disponíveis") }
        item { PlanCard("FREE", listOf("1 perfil", "2 análises Mihh/dia", "Coach por tokens")) }
        item { PlanCard("PRO", listOf("3 perfis", "4 análises/dia", "Booster até 100%", "Coach + vídeo")) }
        item { PlanCard("ELITE", listOf("Perfis ilimitados", "Análises ilimitadas", "Booster até 200%", "Coach + vídeo")) }
    }
}

@Composable
fun PlanCard(name: String, features: List<String>) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(name, fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color(0xFFFF4D4D))
            Spacer(Modifier.height(8.dp))
            features.forEach { Text("• $it") }
        }
    }
}
